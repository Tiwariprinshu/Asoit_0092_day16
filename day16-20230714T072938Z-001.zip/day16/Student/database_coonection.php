<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "student";

    $conn = mysqli_connect($servername, $username, $password,$databasename);
    if($conn -> connect_error)
    {
       
        die($conn -> connect_error);
    }
    else
    {
        echo "MySql Connection Successful!" . '<br/>';
    }

    $query = "INSERT INTO std(std_id,std_name, contact) VALUES('112', 'Prinshu','1234567890')";
    $query = "INSERT INTO std(std_id,std_name, contact) VALUES('113','Jyoti', '997536454')";
    
 
    // $query = "INSERT INTO student2(studentid, firstname, lastname, mnumber, email_id, addr, branch,  sem, createddate, uploaddate) VALUES('1', 'rima', 'shah', '9975486000', 'rs1@gmail.com', 'gandhinagar', 'IT', '4');";

   //$query = "INSERT INTO student2(studentid, firstname, lastname, mnumber, email_id, addr, branch,  sem, createddate, uploaddate) VALUES('2', 'rakesh', 'shah', '9975254600', 'rs1354@gmail.com', 'gandhinagar', 'CIVIL', '4');";

    //$query = "DELETE FROM student2 "
    $query = "INSERT INTO std(std_name, contact) VALUES('Mansi', '997766454')";
    $query = "INSERT INTO std(std_name, contact) VALUES('Kimti', '9975358854')";
    $query = "UPDATE std SET std_name='prin' where std_id='112';";


    $result = $conn->multi_query($query);

    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo "Record Inserted successfully";
    }

   $query = "SELECT * FROM std";
    $result = $conn->query($query);

    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo '<br/>';
        while($row = $result->fetch_assoc())
        {
            echo '<pre/>';
            print_r($row);
            echo "HI" ."". $row["std_name"] . "" .',';
            echo implode('|',$row) . '<br/>';
        }
    }
   
?>