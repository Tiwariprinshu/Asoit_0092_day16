<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "student";

    $conn = mysqli_connect($servername, $username, $password,$databasename);
    if($conn -> connect_error)
    {
       
        die($conn -> connect_error);
    }
    else
    {
        echo "MySql Connection Successful!" . '<br/>';
    }

    $query = "INSERT INTO std (std_id, std_name, contact)
VALUES ('114', 'mansi', '1234567893')";
$query = "INSERT INTO std (std_id, std_name, contact)
VALUES ('116', 'Radha', '1234567893')";
    $query = "UPDATE std SET std_name='prinshu' where std_id='112';";
    $result = $conn->multi_query($query);


    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo "Record Inserted successfully";
    }

   $query = "SELECT * FROM std";
    $result = $conn->query($query);

    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo '<br/>';
        while($row = $result->fetch_assoc())
        {
            echo '<pre/>';
            print_r($row);
            echo "HI" ."". $row["std_name"] . "" .',';
            echo implode('|',$row) . '<br/>';
        }
    }
   
?>